// EVCharge 新能源汽车智能服务平台 - 前端逻辑
class EVChargeApp {
    constructor() {
        this.map = null;
        this.currentLocation = null;
        this.markers = [];
        this.polyline = null;
        // 自动检测后端地址，支持局域网和公网访问
        this.backendUrl = this.getBackendUrl();
        this.apiKey = 'b3e4925855770e4c79aea6f7c24b051b';
        this.apiKeyBackup = 'e9f2dd5c2025ab00ea8bba1a19bee083'; // 备用密钥
        this.apiCalls = 0;
        this.lastActivity = [];
        
        // 通知系统
        this.notifications = [];
        this.notificationRefreshInterval = null;
        this.lastNotificationUpdate = null;
        
        this.init();
    }
    
    getBackendUrl() {
        // 自动获取当前页面的协议和主机，支持公网访问
        const protocol = window.location.protocol;
        const hostname = window.location.hostname;
        const port = window.location.port;
        
        // 如果有端口，使用当前端口；否则默认3000
        const backendPort = port || '3000';
        
        // 构建后端URL
        const url = `${protocol}//${hostname}:${backendPort}`;
        
        console.log(`🔗 自动检测后端地址: ${url}`);
        return url;
    }

    async init() {
        console.log('🚗 EVCharge 新能源汽车智能服务平台启动中...');
        
        // 显示加载动画
        this.showLoading();
        
        // 初始化地图
        await this.initMap();
        
        // 绑定事件
        this.bindEvents();
        
        // 检查后端状态
        await this.checkBackendStatus();
        
        // 获取初始位置
        await this.getCurrentLocation();
        
        // 加载示例数据
        this.loadSampleData();
        
        // 隐藏加载动画
        this.hideLoading();
        
        // 更新最后更新时间
        this.updateLastUpdateTime();
        
        // 初始化通知系统
        this.initNotificationSystem();
        
        console.log('✅ 系统初始化完成');
    }

    async initMap() {
        return new Promise((resolve) => {
            // 初始化高德地图
            this.map = new AMap.Map('map', {
                zoom: 13,
                center: [116.397428, 39.90923],
                viewMode: '3D',
                resizeEnable: true,
                mapStyle: 'amap://styles/blue',
                pitch: 45,
                rotation: 0
            });

            // 添加地图控件
            AMap.plugin(['AMap.ToolBar', 'AMap.Scale', 'AMap.OverView', 'AMap.MapType'], () => {
                this.map.addControl(new AMap.ToolBar({
                    liteStyle: false
                }));
                this.map.addControl(new AMap.Scale());
                this.map.addControl(new AMap.MapType({
                    defaultType: 0
                }));
            });

            // 3D建筑功能暂时移除，因为API版本可能不支持
            console.log('3D地图初始化完成，已启用3D视图模式');
            console.log('地图配置:', {
                zoom: this.map.getZoom(),
                center: this.map.getCenter(),
                pitch: this.map.getPitch(),
                rotation: this.map.getRotation()
            });

            // 监听地图变化
            this.map.on('zoomchange', () => {
                document.getElementById('zoom-level').textContent = this.map.getZoom();
            });

            this.map.on('moveend', () => {
                const center = this.map.getCenter();
                document.getElementById('center-coords').textContent = 
                    `${center.lng.toFixed(6)}, ${center.lat.toFixed(6)}`;
            });

            this.map.on('complete', () => {
                console.log('3D地图加载完成');
            });

            resolve();
        });
    }

    bindEvents() {
        // 定位按钮
        document.getElementById('locate-btn').addEventListener('click', () => {
            this.getCurrentLocation();
            this.addActivity('更新位置', '用户手动更新了当前位置');
        });

        // 搜索按钮
        document.getElementById('search-btn').addEventListener('click', () => {
            this.searchChargingStations();
            this.addActivity('搜索充电桩', '用户搜索了附近的充电桩');
        });

        // 路线规划按钮
        document.getElementById('plan-route-btn').addEventListener('click', () => {
            this.planRoute();
            this.addActivity('路线规划', '用户进行了路线规划');
        });

        // 地图控制按钮
        document.getElementById('map-zoom-in').addEventListener('click', () => {
            this.map.zoomIn();
        });

        document.getElementById('map-zoom-out').addEventListener('click', () => {
            this.map.zoomOut();
        });

        document.getElementById('map-locate').addEventListener('click', () => {
            this.locateOnMap();
        });

        document.getElementById('map-fullscreen').addEventListener('click', () => {
            this.toggleFullscreen();
        });

        // 搜索输入框回车事件
        document.getElementById('search-input').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.searchChargingStations();
            }
        });

        // 目的地输入框回车事件
        document.getElementById('destination-input').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.planRoute();
            }
        });

        // 用户信息点击事件 - 切换下拉菜单
        document.querySelector('.user-info').addEventListener('click', (e) => {
            e.stopPropagation();
            this.toggleUserDropdown();
        });

        // 点击页面其他地方关闭下拉菜单
        document.addEventListener('click', (e) => {
            // 关闭用户下拉菜单
            const userDropdown = document.querySelector('.user-dropdown');
            if (userDropdown && !userDropdown.contains(e.target)) {
                userDropdown.classList.remove('active');
            }
            
            // 关闭通知下拉菜单
            const notificationDropdown = document.querySelector('.notification-dropdown');
            const notificationBtn = document.querySelector('.btn-notification');
            if (notificationDropdown && !notificationDropdown.contains(e.target)) {
                notificationDropdown.classList.remove('active');
            }
        });

        // 通知按钮点击事件
        document.querySelector('.btn-notification').addEventListener('click', (e) => {
            e.stopPropagation();
            this.showNotifications();
        });
    }

    async getCurrentLocation() {
        const locationEl = document.getElementById('current-location');
        locationEl.innerHTML = '<span class="loading"></span> 获取位置中...';

        try {
            // 使用浏览器定位
            if (navigator.geolocation) {
                const position = await this.getBrowserLocation();
                const { latitude, longitude } = position.coords;
                this.currentLocation = `${longitude},${latitude}`;
                
                // 获取地址信息
                const address = await this.reverseGeocode(this.currentLocation);
                locationEl.textContent = address;
                
                // 在地图上标记
                this.markCurrentLocation(longitude, latitude, address);
                
                // 更新起点输入框
                document.getElementById('origin-input').value = '当前位置';
                
                // 更新连接状态
                this.updateConnectionStatus('在线');
                
            } else {
                throw new Error('浏览器不支持定位');
            }
        } catch (error) {
            console.warn('浏览器定位失败，使用IP定位:', error);
            await this.getIPLocation();
        }
    }

    getBrowserLocation() {
        return new Promise((resolve, reject) => {
            navigator.geolocation.getCurrentPosition(resolve, reject, {
                enableHighAccuracy: true,
                timeout: 10000,
                maximumAge: 0
            });
        });
    }

    async getIPLocation() {
        try {
            const response = await this.apiRequest('/location/ip');
            if (response.status === '1') {
                const location = response.rectangle.split(';')[0];
                const [lng, lat] = location.split(',').map(Number);
                this.currentLocation = `${lng},${lat}`;
                
                const address = await this.reverseGeocode(this.currentLocation);
                document.getElementById('current-location').textContent = address;
                
                this.markCurrentLocation(lng, lat, address);
            }
        } catch (error) {
            console.error('IP定位失败:', error);
            document.getElementById('current-location').textContent = '定位失败，请检查网络';
            document.getElementById('connection-status').textContent = '离线';
            document.getElementById('connection-status').className = 'status-offline';
        }
    }

    async searchChargingStations() {
        const input = document.getElementById('search-input').value;
        const radius = document.getElementById('radius-select').value;
        const resultsEl = document.getElementById('search-results');
        
        if (!input) {
            this.showNotification('请输入搜索地址', 'warning');
            return;
        }

        this.showLoading();
        
        try {
            let location = this.currentLocation;
            
            // 如果输入了地址，进行地理编码
            if (input && input !== '当前位置') {
                location = await this.geocode(input);
            }

            // 搜索充电桩
            const response = await this.apiRequest('/charging-stations', {
                location: location,
                radius: radius
            });
            
            this.displaySearchResults(response.pois || []);
            
            // 更新统计信息
            this.updateStats(response.pois || []);
            
            this.showNotification(`找到 ${response.pois?.length || 0} 个充电桩`, 'success');
            
        } catch (error) {
            console.error('搜索失败:', error);
            this.showNotification('搜索失败，请重试', 'error');
        } finally {
            this.hideLoading();
        }
    }

    displaySearchResults(stations) {
        const resultsEl = document.getElementById('search-results');
        const resultsCount = document.getElementById('results-count');
        
        resultsEl.innerHTML = '';
        resultsCount.textContent = `${stations.length}个`;
        
        if (stations.length === 0) {
            resultsEl.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-search"></i>
                    <p>未找到充电桩</p>
                </div>
            `;
            return;
        }

        stations.forEach((station, index) => {
            const stationEl = document.createElement('div');
            stationEl.className = 'result-item';
            stationEl.innerHTML = `
                <div class="result-header">
                    <div class="result-title">
                        <i class="fas fa-charging-station"></i>
                        ${station.name}
                    </div>
                    <div class="result-distance">
                        ${station.distance ? (station.distance / 1000).toFixed(1) + 'km' : '未知'}
                    </div>
                </div>
                <div class="result-details">
                    <div class="result-detail">
                        <i class="fas fa-map-marker-alt"></i>
                        <span>${station.address || '地址未知'}</span>
                    </div>
                    <div class="result-detail">
                        <i class="fas fa-phone"></i>
                        <span>${station.tel || '电话未知'}</span>
                    </div>
                    <div class="result-detail">
                        <i class="fas fa-bolt"></i>
                        <span>${station.type || '充电站'}</span>
                    </div>
                </div>
            `;
            
            stationEl.addEventListener('click', () => {
                this.showStationDetails(station);
            });
            
            resultsEl.appendChild(stationEl);
        });

        // 在地图上显示充电桩
        this.showChargingStationsOnMap(stations);
    }

    showChargingStationsOnMap(stations) {
        // 清除之前的标记
        this.clearMarkers();
        
        stations.forEach(station => {
            const [lng, lat] = station.location.split(',').map(Number);
            
            const marker = new AMap.Marker({
                position: new AMap.LngLat(lng, lat),
                title: station.name,
                content: `
                    <div style="
                        position: relative;
                        width: 40px;
                        height: 40px;
                    ">
                        <!-- 3D底座 -->
                        <div style="
                            position: absolute;
                            bottom: 0;
                            left: 50%;
                            transform: translateX(-50%);
                            width: 30px;
                            height: 6px;
                            background: linear-gradient(90deg, #00f0ff 0%, #0066ff 100%);
                            border-radius: 3px;
                            box-shadow: 0 0 15px rgba(0, 240, 255, 0.8);
                        "></div>
                        <!-- 发光光环 -->
                        <div style="
                            position: absolute;
                            bottom: 3px;
                            left: 50%;
                            transform: translateX(-50%);
                            width: 40px;
                            height: 40px;
                            background: radial-gradient(circle, rgba(0,240,255,0.3) 0%, transparent 70%);
                            border-radius: 50%;
                            animation: pulse 2s ease-in-out infinite;
                        "></div>
                        <!-- 充电桩图标 -->
                        <div style="
                            position: absolute;
                            top: 0;
                            left: 50%;
                            transform: translateX(-50%);
                            background: linear-gradient(135deg, #00f0ff 0%, #0066ff 100%);
                            color: white;
                            width: 36px;
                            height: 36px;
                            border-radius: 50%;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            border: 2px solid rgba(255, 255, 255, 0.8);
                            box-shadow: 0 0 20px rgba(0, 240, 255, 0.8);
                            cursor: pointer;
                            transition: all 0.3s ease;
                        ">
                            <i class="fas fa-bolt" style="font-size: 18px;"></i>
                        </div>
                    </div>
                    <style>
                        @keyframes pulse {
                            0%, 100% {
                                transform: translateX(-50%) scale(1);
                                opacity: 0.6;
                            }
                            50% {
                                transform: translateX(-50%) scale(1.2);
                                opacity: 0.9;
                            }
                        }
                    </style>
                `
            });

            marker.on('click', () => {
                this.showStationDetails(station);
            });

            this.map.add(marker);
            this.markers.push(marker);
        });

        // 调整地图视野
        if (stations.length > 0) {
            const bounds = this.map.getBounds();
            this.map.setBounds(bounds);
        }
    }

    async planRoute() {
        const origin = document.getElementById('origin-input').value;
        const destination = document.getElementById('destination-input').value;
        const waypoints = document.getElementById('waypoint-select').value;
        const routeInfoEl = document.getElementById('route-info');

        if (!destination) {
            this.showNotification('请输入目的地', 'warning');
            return;
        }

        this.showLoading();
        
        try {
            let originLocation = this.currentLocation;
            if (origin && origin !== '当前位置') {
                originLocation = await this.geocode(origin);
            }

            const destinationLocation = await this.geocode(destination);

            const params = {
                origin: originLocation,
                destination: destinationLocation
            };

            if (waypoints) {
                params.waypoints = waypoints;
            }

            const response = await this.apiRequest('/route-planning', params);
            
            if (response.route?.paths?.[0]) {
                this.displayRouteInfo(response.route);
                this.showRouteOnMap(response.route);
                this.showNotification('路线规划完成', 'success');
                this.saveRouteData({
                    origin: originLocation,
                    destination: destinationLocation,
                    route: response.route
                });
            } else {
                throw new Error('路线规划失败');
            }

        } catch (error) {
            console.error('路线规划失败:', error);
            this.showNotification('路线规划失败', 'error');
        } finally {
            this.hideLoading();
        }
    }

    displayRouteInfo(route) {
        const routeInfoEl = document.getElementById('route-info');
        const path = route.paths[0];
        
        const distance = (path.distance / 1000).toFixed(1);
        const duration = Math.floor(path.duration / 60);
        const tolls = path.tolls || 0;
        const cost = path.cost || 0;

        routeInfoEl.innerHTML = `
            <div class="route-summary">
                <h4>🗺️ 路线规划完成</h4>
                <p><i class="fas fa-road text-primary"></i> <strong>距离:</strong> ${distance} 公里</p>
                <p><i class="fas fa-clock text-primary"></i> <strong>预计时间:</strong> ${duration} 分钟</p>
                <p><i class="fas fa-tag text-primary"></i> <strong>过路费:</strong> ${tolls} 元</p>
                <p><i class="fas fa-bolt text-primary"></i> <strong>预估电费:</strong> ${(distance * 0.15).toFixed(1)} 元</p>
                <p><i class="fas fa-car text-primary"></i> <strong>预计消耗电量:</strong> ${((distance / 350) * 100).toFixed(1)}%</p>
            </div>
        `;

        routeInfoEl.classList.add('active');
        
        // 更新电池状态
        this.updateBatteryStatus(distance);
    }

    showRouteOnMap(route) {
        // 清除之前的路线
        if (this.polyline) {
            this.map.remove(this.polyline);
        }

        const path = route.paths[0];
        if (path && path.steps) {
            const lineArr = [];
            path.steps.forEach(step => {
                const polyline = step.polyline;
                const points = polyline.split(';');
                points.forEach(point => {
                    const [lng, lat] = point.split(',').map(Number);
                    lineArr.push([lng, lat]);
                });
            });

            // 创建3D路线
            // 底层发光效果
            const glowLine = new AMap.Polyline({
                path: lineArr,
                strokeColor: "#00f0ff",
                strokeWeight: 12,
                strokeOpacity: 0.4,
                strokeStyle: "solid",
                lineJoin: "round",
                lineCap: "round"
            });

            // 中层主路线
            const mainLine = new AMap.Polyline({
                path: lineArr,
                strokeColor: "#0066ff",
                strokeWeight: 6,
                strokeOpacity: 0.9,
                strokeStyle: "solid",
                lineJoin: "round",
                lineCap: "round"
            });

            // 上层高亮效果
            const highlightLine = new AMap.Polyline({
                path: lineArr,
                strokeColor: "#ffffff",
                strokeWeight: 2,
                strokeOpacity: 0.6,
                strokeStyle: "solid",
                lineJoin: "round",
                lineCap: "round"
            });

            // 添加到地图
            this.map.add(glowLine);
            this.map.add(mainLine);
            this.map.add(highlightLine);

            // 保存路线对象
            this.polyline = mainLine;
            this.map.setFitView();

            // 添加路线动画效果
            this.animateRoute(lineArr);
        }
    }

    animateRoute(path) {
        // 创建路线动画效果
        if (path.length > 0) {
            // 可以在这里添加路线动画逻辑
            console.log('路线动画已启动');
        }
    }

    markCurrentLocation(lng, lat, address) {
        // 清除之前的定位标记
        this.clearCurrentMarker();
        
        const marker = new AMap.Marker({
            position: new AMap.LngLat(lng, lat),
            title: '当前位置',
            content: `
                <div style="
                    position: relative;
                    width: 56px;
                    height: 56px;
                ">
                    <!-- 3D底座 -->
                    <div style="
                        position: absolute;
                        bottom: 0;
                        left: 50%;
                        transform: translateX(-50%);
                        width: 40px;
                        height: 8px;
                        background: linear-gradient(90deg, #4361ee 0%, #3a0ca3 100%);
                        border-radius: 4px;
                        box-shadow: 0 0 20px rgba(67, 97, 238, 0.8);
                    "></div>
                    <!-- 发光光环 -->
                    <div style="
                        position: absolute;
                        bottom: 4px;
                        left: 50%;
                        transform: translateX(-50%);
                        width: 56px;
                        height: 56px;
                        background: radial-gradient(circle, rgba(67, 97, 238, 0.4) 0%, transparent 70%);
                        border-radius: 50%;
                        animation: pulse 2s ease-in-out infinite;
                    "></div>
                    <!-- 车辆图标 -->
                    <div style="
                        position: absolute;
                        top: 0;
                        left: 50%;
                        transform: translateX(-50%);
                        background: linear-gradient(135deg, #4361ee 0%, #3a0ca3 100%);
                        color: white;
                        width: 48px;
                        height: 48px;
                        border-radius: 50%;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        border: 2px solid rgba(255, 255, 255, 0.8);
                        box-shadow: 0 0 25px rgba(67, 97, 238, 0.8);
                        cursor: pointer;
                        transition: all 0.3s ease;
                    ">
                        <i class="fas fa-car" style="font-size: 22px;"></i>
                    </div>
                    <!-- 顶部发光效果 -->
                    <div style="
                        position: absolute;
                        top: -4px;
                        left: 50%;
                        transform: translateX(-50%);
                        width: 32px;
                        height: 8px;
                        background: linear-gradient(90deg, transparent, #ffffff, transparent);
                        border-radius: 4px;
                        opacity: 0.8;
                        animation: scan 3s ease-in-out infinite;
                    "></div>
                </div>
                <style>
                    @keyframes pulse {
                        0%, 100% {
                            transform: translateX(-50%) scale(1);
                            opacity: 0.6;
                        }
                        50% {
                            transform: translateX(-50%) scale(1.2);
                            opacity: 0.9;
                        }
                    }
                    @keyframes scan {
                        0%, 100% {
                            transform: translateX(-50%) translateY(0);
                            opacity: 0;
                        }
                        50% {
                            transform: translateX(-50%) translateY(20px);
                            opacity: 0.8;
                        }
                    }
                </style>
            `
        });

        marker.on('click', () => {
            new AMap.InfoWindow({
                content: `
                    <div style="padding: 16px; max-width: 220px; background: rgba(26, 32, 44, 0.95); border-radius: 12px; border: 1px solid rgba(67, 97, 238, 0.5); backdrop-filter: blur(10px);">
                        <h4 style="margin: 0 0 12px 0; color: #4361ee; text-shadow: 0 0 10px rgba(67, 97, 238, 0.5);">当前位置</h4>
                        <p style="margin: 8px 0; color: #e2e8f0;">${address}</p>
                        <p style="margin: 8px 0; color: #a0aec0; font-size: 0.9em;">
                            坐标: ${lng.toFixed(6)}, ${lat.toFixed(6)}
                        </p>
                        <div style="margin-top: 12px; padding-top: 12px; border-top: 1px solid rgba(67, 97, 238, 0.3);">
                            <p style="margin: 0; color: #00f0ff; font-size: 0.85em;">
                                <i class="fas fa-satellite"></i> 定位精度: 10m
                            </p>
                        </div>
                    </div>
                `,
                offset: new AMap.Pixel(0, -60)
            }).open(this.map, marker.getPosition());
        });

        this.map.add(marker);
        this.markers.push(marker);
        
        // 移动到当前位置
        this.map.setCenter([lng, lat]);
        this.map.setZoom(15);
    }

    locateOnMap() {
        if (this.currentLocation) {
            const [lng, lat] = this.currentLocation.split(',').map(Number);
            this.map.setCenter([lng, lat]);
            this.map.setZoom(15);
            this.showNotification('已定位到当前位置', 'info');
        }
    }

    showStationDetails(station) {
        const [lng, lat] = station.location.split(',').map(Number);
        
        new AMap.InfoWindow({
            content: `
                <div style="padding: 16px; max-width: 280px;">
                    <h4 style="margin: 0 0 12px 0; color: #4361ee; font-size: 1.1em;">
                        <i class="fas fa-charging-station"></i> ${station.name}
                    </h4>
                    <div style="margin-bottom: 12px;">
                        <p style="margin: 6px 0; color: #666;">
                            <i class="fas fa-map-marker-alt" style="color: #4361ee; width: 16px;"></i>
                            ${station.address || '地址未知'}
                        </p>
                        <p style="margin: 6px 0; color: #666;">
                            <i class="fas fa-phone" style="color: #4361ee; width: 16px;"></i>
                            ${station.tel || '电话未知'}
                        </p>
                        <p style="margin: 6px 0; color: #666;">
                            <i class="fas fa-ruler" style="color: #4361ee; width: 16px;"></i>
                            距离: ${station.distance ? (station.distance / 1000).toFixed(2) + '公里' : '未知'}
                        </p>
                    </div>
                    <div style="display: flex; gap: 8px; margin-top: 16px;">
                        <button onclick="evChargeApp.setAsWaypoint('${station.location}', '${station.name}')" 
                                style="flex: 1; padding: 8px 12px; background: #4361ee; color: white; border: none; border-radius: 6px; cursor: pointer;">
                            设为途经点
                        </button>
                        <button onclick="evChargeApp.navigateToStation(${lng}, ${lat})" 
                                style="flex: 1; padding: 8px 12px; background: #4ade80; color: white; border: none; border-radius: 6px; cursor: pointer;">
                            导航前往
                        </button>
                    </div>
                </div>
            `,
            offset: new AMap.Pixel(0, -40)
        }).open(this.map, [lng, lat]);
    }

    setAsWaypoint(location, name) {
        const select = document.getElementById('waypoint-select');
        const option = document.createElement('option');
        option.value = location;
        option.textContent = `${name} (途经点)`;
        select.appendChild(option);
        select.value = location;
        
        this.showNotification(`已将"${name}"设为途经点`, 'success');
        this.addActivity('设置途经点', `设置 ${name} 为途经点`);
    }

    navigateToStation(lng, lat) {
        if (this.currentLocation) {
            const [currentLng, currentLat] = this.currentLocation.split(',').map(Number);
            this.map.setCenter([lng, lat]);
            this.map.setZoom(16);
            this.showNotification('已定位到充电站位置', 'info');
        }
    }

    updateBatteryStatus(distance) {
        const batteryRangeEl = document.getElementById('battery-range');
        const batteryLevelEl = document.querySelector('.battery-level');
        
        let currentRange = 286; // 从车辆状态卡片获取
        let newRange = currentRange - distance;
        let newPercentage = (newRange / 400) * 100; // 假设满电400km
        
        if (newPercentage < 0) newPercentage = 0;
        if (newPercentage > 100) newPercentage = 100;
        
        // 更新UI
        batteryLevelEl.style.width = `${newPercentage}%`;
        document.querySelector('.percentage').textContent = `${Math.round(newPercentage)}%`;
        
        if (newPercentage < 20) {
            this.showNotification('⚠️ 电池电量低，建议立即充电！', 'warning');
        } else if (newPercentage < 40) {
            this.showNotification('🔋 电池电量中等，建议规划充电', 'info');
        }
    }

    updateStats(stations) {
        document.getElementById('total-stations').textContent = stations.length;
        
        const fastChargers = stations.filter(s => s.type?.includes('快充') || s.name?.includes('快充')).length;
        document.getElementById('fast-chargers').textContent = fastChargers;
        
        const availableChargers = Math.floor(stations.length * 0.7); // 模拟70%可用
        document.getElementById('available-chargers').textContent = availableChargers;
        
        if (stations.length > 0) {
            let totalDistance = 0;
            let validStations = 0;
            
            stations.forEach(station => {
                const distance = parseFloat(station.distance);
                if (!isNaN(distance) && distance > 0 && distance < 1000000) { // 过滤掉异常值
                    totalDistance += distance;
                    validStations++;
                }
            });
            
            const avgDistance = validStations > 0 ? (totalDistance / validStations / 1000).toFixed(1) : '0.0';
            document.getElementById('avg-distance').textContent = `${avgDistance} km`;
        }
    }

    async apiRequest(endpoint, params = {}) {
        this.apiCalls++;
        document.getElementById('api-calls').textContent = this.apiCalls;
        
        const url = new URL(`${this.backendUrl}/api${endpoint}`);
        Object.keys(params).forEach(key => {
            url.searchParams.append(key, params[key]);
        });
        
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`API请求失败: ${response.status}`);
        }
        return await response.json();
    }

    async geocode(address) {
        const response = await this.apiRequest('/geocode', { address });
        if (response.status === '1' && response.geocodes.length > 0) {
            return response.geocodes[0].location;
        }
        throw new Error('地址解析失败');
    }

    async reverseGeocode(location) {
        const response = await this.apiRequest('/reverse-geocode', { location });
        if (response.status === '1') {
            return response.regeocode.formatted_address;
        }
        return '未知位置';
    }

    async checkBackendStatus() {
        try {
            const response = await this.apiRequest('/health');
            document.getElementById('backend-status').textContent = '在线';
            document.getElementById('connection-status').textContent = '在线';
            document.getElementById('map-status').textContent = '正常';
            return true;
        } catch (error) {
            console.error('后端连接失败:', error);
            document.getElementById('backend-status').textContent = '离线';
            document.getElementById('connection-status').textContent = '离线';
            document.getElementById('connection-status').className = 'status-offline';
            document.getElementById('map-status').textContent = '异常';
            return false;
        }
    }

    updateConnectionStatus(status) {
        const statusEl = document.getElementById('connection-status');
        statusEl.textContent = status;
        statusEl.className = status === '在线' ? 'status-online' : 'status-offline';
    }

    updateLastUpdateTime() {
        const now = new Date();
        const timeStr = now.toLocaleTimeString('zh-CN', { 
            hour: '2-digit', 
            minute: '2-digit' 
        });
        document.getElementById('last-update').textContent = timeStr;
        
        // 每分钟更新一次
        setInterval(() => {
            const now = new Date();
            const timeStr = now.toLocaleTimeString('zh-CN', { 
                hour: '2-digit', 
                minute: '2-digit' 
            });
            document.getElementById('last-update').textContent = timeStr;
        }, 60000);
    }

    addActivity(title, description) {
        const activityList = document.querySelector('.activity-list');
        const now = new Date();
        const timeStr = now.toLocaleTimeString('zh-CN', { 
            hour: '2-digit', 
            minute: '2-digit' 
        });
        
        const activityItem = document.createElement('div');
        activityItem.className = 'activity-item';
        activityItem.innerHTML = `
            <div class="activity-icon">
                <i class="fas fa-history"></i>
            </div>
            <div class="activity-content">
                <div class="activity-title">${title}</div>
                <div class="activity-time">${timeStr}</div>
            </div>
        `;
        
        // 添加到列表顶部
        activityList.insertBefore(activityItem, activityList.firstChild);
        
        // 限制最多显示5条
        const items = activityList.querySelectorAll('.activity-item');
        if (items.length > 5) {
            activityList.removeChild(items[items.length - 1]);
        }
    }

    initNotificationSystem() {
        // 初始化通知系统
        console.log('🔔 初始化实时通知系统...');
        
        // 加载初始通知
        this.loadInitialNotifications();
        
        // 启动实时更新（每30秒刷新一次）
        this.notificationRefreshInterval = setInterval(() => {
            this.refreshNotifications();
        }, 30000);
        
        console.log('✅ 实时通知系统已启动，每30秒自动刷新');
    }

    loadInitialNotifications() {
        // 加载初始通知数据
        this.notifications = [
            { id: Date.now(), title: '系统启动', message: 'EVCharge智能服务平台已启动', time: '刚刚', type: 'success', read: false },
            { id: Date.now() - 1, title: '位置更新', message: '已获取您的当前位置', time: '1分钟前', type: 'info', read: false }
        ];
        
        this.updateNotificationBadge();
    }

    async refreshNotifications() {
        // 实时刷新通知
        try {
            const response = await this.fetchNotificationsFromBackend();
            
            if (response && response.notifications && response.notifications.length > 0) {
                // 合并新通知
                response.notifications.forEach(newNotif => {
                    const exists = this.notifications.some(n => n.id === newNotif.id);
                    if (!exists) {
                        this.notifications.unshift(newNotif);
                        this.showNotification(`📢 ${newNotif.title}: ${newNotif.message}`, newNotif.type);
                    }
                });
                
                // 保持最多50条通知
                if (this.notifications.length > 50) {
                    this.notifications = this.notifications.slice(0, 50);
                }
                
                this.updateNotificationBadge();
                this.lastNotificationUpdate = new Date();
            }
        } catch (error) {
            console.log('📡 通知刷新失败，使用本地数据:', error.message);
            // 如果后端不可用，模拟生成新通知
            this.generateMockNotification();
        }
    }

    async fetchNotificationsFromBackend() {
        // 从后端获取通知
        try {
            const response = await fetch(`${this.backendUrl}/api/notifications`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            
            if (response.ok) {
                return await response.json();
            }
        } catch (error) {
            console.log('后端通知接口不可用');
        }
        return null;
    }

    generateMockNotification() {
        // 模拟生成随机通知
        const notificationTypes = ['info', 'success', 'warning'];
        const notificationTemplates = [
            { title: '充电桩更新', message: '附近新增充电桩', type: 'success' },
            { title: '电量提醒', message: '建议及时充电', type: 'warning' },
            { title: '路线优化', message: '推荐路线已更新', type: 'info' },
            { title: '系统提示', message: '地图数据已更新', type: 'info' },
            { title: '天气提醒', message: '今日天气适宜出行', type: 'success' }
        ];
        
        // 随机决定是否生成新通知（30%概率）
        if (Math.random() < 0.3) {
            const template = notificationTemplates[Math.floor(Math.random() * notificationTemplates.length)];
            const newNotif = {
                id: Date.now(),
                title: template.title,
                message: template.message,
                time: '刚刚',
                type: template.type,
                read: false
            };
            
            this.notifications.unshift(newNotif);
            this.updateNotificationBadge();
            this.showNotification(`📢 ${newNotif.title}: ${newNotif.message}`, newNotif.type);
        }
    }

    updateNotificationBadge() {
        // 更新通知徽章数量
        const badge = document.querySelector('.notification-badge');
        const unreadCount = this.notifications.filter(n => !n.read).length;
        
        if (badge) {
            if (unreadCount > 0) {
                badge.style.display = 'flex';
                badge.textContent = unreadCount > 9 ? '9+' : unreadCount.toString();
            } else {
                badge.style.display = 'none';
            }
        }
    }

    loadSampleData() {
        // 加载示例搜索地址
        const sampleAddresses = [
            '北京市朝阳区国贸',
            '上海市浦东新区陆家嘴',
            '广州市天河区珠江新城',
            '深圳市南山区科技园'
        ];
        
        const searchInput = document.getElementById('search-input');
        searchInput.placeholder = `例如: ${sampleAddresses[Math.floor(Math.random() * sampleAddresses.length)]}`;
        
        // 加载示例目的地
        const sampleDestinations = [
            '北京首都国际机场',
            '上海虹桥火车站',
            '广州南站',
            '深圳宝安国际机场'
        ];
        
        const destInput = document.getElementById('destination-input');
        destInput.placeholder = `例如: ${sampleDestinations[Math.floor(Math.random() * sampleDestinations.length)]}`;
    }

    toggleUserDropdown() {
        // 切换用户下拉菜单显示/隐藏
        const dropdown = document.querySelector('.user-dropdown');
        const userInfo = document.querySelector('.user-info');
        
        if (dropdown) {
            dropdown.classList.toggle('active');
            userInfo.classList.toggle('open');
        }
    }

    showVehicleInfo() {
        // 显示车辆信息
        this.toggleUserDropdown();
        const vehicleInfo = {
            model: '特斯拉 Model 3',
            battery: '85%',
            mileage: '380 km',
            lastCharge: '2小时前',
            totalMileage: '12,580 km',
            efficiency: '15.2 kWh/100km'
        };
        
        const panelContent = `
            <div style="padding: 15px; background: rgba(0,0,0,0.8); border-radius: 12px; color: white; max-width: 320px;">
                <h3 style="color: #00f0ff; margin-bottom: 15px;">🚗 车辆信息</h3>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                    <div style="background: rgba(0,240,255,0.1); padding: 12px; border-radius: 8px;">
                        <p style="margin: 0; font-size: 0.85rem; opacity: 0.7;">车型</p>
                        <p style="margin: 5px 0 0 0; font-weight: bold;">${vehicleInfo.model}</p>
                    </div>
                    <div style="background: rgba(0,240,255,0.1); padding: 12px; border-radius: 8px;">
                        <p style="margin: 0; font-size: 0.85rem; opacity: 0.7;">电池电量</p>
                        <p style="margin: 5px 0 0 0; font-weight: bold; color: #4ade80;">${vehicleInfo.battery}</p>
                    </div>
                    <div style="background: rgba(0,240,255,0.1); padding: 12px; border-radius: 8px;">
                        <p style="margin: 0; font-size: 0.85rem; opacity: 0.7;">续航里程</p>
                        <p style="margin: 5px 0 0 0; font-weight: bold;">${vehicleInfo.mileage}</p>
                    </div>
                    <div style="background: rgba(0,240,255,0.1); padding: 12px; border-radius: 8px;">
                        <p style="margin: 0; font-size: 0.85rem; opacity: 0.7;">上次充电</p>
                        <p style="margin: 5px 0 0 0; font-weight: bold;">${vehicleInfo.lastCharge}</p>
                    </div>
                    <div style="background: rgba(0,240,255,0.1); padding: 12px; border-radius: 8px;">
                        <p style="margin: 0; font-size: 0.85rem; opacity: 0.7;">总里程</p>
                        <p style="margin: 5px 0 0 0; font-weight: bold;">${vehicleInfo.totalMileage}</p>
                    </div>
                    <div style="background: rgba(0,240,255,0.1); padding: 12px; border-radius: 8px;">
                        <p style="margin: 0; font-size: 0.85rem; opacity: 0.7;">能耗效率</p>
                        <p style="margin: 5px 0 0 0; font-weight: bold;">${vehicleInfo.efficiency}</p>
                    </div>
                </div>
            </div>
        `;
        
        const modal = document.createElement('div');
        modal.className = 'modal-overlay';
        modal.innerHTML = panelContent;
        modal.addEventListener('click', () => {
            modal.remove();
        });
        document.body.appendChild(modal);
    }

    showChargingHistory() {
        // 显示充电记录
        this.toggleUserDropdown();
        const chargingHistory = [
            { date: '2024-01-15', station: '国贸充电站', type: '快充', duration: '45分钟', amount: '45 kWh', cost: '32元' },
            { date: '2024-01-14', station: '望京SOHO站', type: '慢充', duration: '3小时', amount: '32 kWh', cost: '18元' },
            { date: '2024-01-13', station: '三里屯站', type: '超充', duration: '20分钟', amount: '55 kWh', cost: '42元' }
        ];
        
        let historyList = `
            <div style="padding: 15px; background: rgba(0,0,0,0.8); border-radius: 12px; color: white; max-width: 400px; max-height: 450px; overflow-y: auto;">
                <h3 style="color: #00f0ff; margin-bottom: 15px;">📊 充电记录</h3>
        `;
        
        chargingHistory.forEach(record => {
            const typeColor = record.type === '快充' ? '#4ade80' : record.type === '超充' ? '#f59e0b' : '#4361ee';
            historyList += `
                <div style="padding: 12px; border-bottom: 1px solid rgba(255,255,255,0.1); margin-bottom: 8px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                        <span style="font-weight: bold;">${record.station}</span>
                        <span style="color: ${typeColor}; font-size: 0.8rem; padding: 2px 8px; background: rgba(255,255,255,0.1); border-radius: 4px;">${record.type}</span>
                    </div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; font-size: 0.85rem;">
                        <div><span style="opacity: 0.7;">日期:</span> ${record.date}</div>
                        <div><span style="opacity: 0.7;">时长:</span> ${record.duration}</div>
                        <div><span style="opacity: 0.7;">电量:</span> ${record.amount}</div>
                        <div><span style="opacity: 0.7;">费用:</span> <span style="color: #f59e0b;">${record.cost}</span></div>
                    </div>
                </div>
            `;
        });
        
        historyList += '</div>';
        
        const modal = document.createElement('div');
        modal.className = 'modal-overlay';
        modal.innerHTML = historyList;
        modal.addEventListener('click', () => {
            modal.remove();
        });
        document.body.appendChild(modal);
    }

    showSettings() {
        // 显示系统设置
        this.toggleUserDropdown();
        const settingsContent = `
            <div style="padding: 15px; background: rgba(0,0,0,0.8); border-radius: 12px; color: white; max-width: 350px;">
                <h3 style="color: #00f0ff; margin-bottom: 15px;">⚙️ 系统设置</h3>
                <div style="display: flex; flex-direction: column; gap: 12px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 10px; background: rgba(0,240,255,0.1); border-radius: 8px;">
                        <div>
                            <p style="margin: 0; font-weight: bold;">实时通知</p>
                            <p style="margin: 2px 0 0 0; font-size: 0.8rem; opacity: 0.7;">接收系统推送通知</p>
                        </div>
                        <label class="switch">
                            <input type="checkbox" checked>
                            <span class="slider"></span>
                        </label>
                    </div>
                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 10px; background: rgba(0,240,255,0.1); border-radius: 8px;">
                        <div>
                            <p style="margin: 0; font-weight: bold;">位置追踪</p>
                            <p style="margin: 2px 0 0 0; font-size: 0.8rem; opacity: 0.7;">自动更新位置信息</p>
                        </div>
                        <label class="switch">
                            <input type="checkbox" checked>
                            <span class="slider"></span>
                        </label>
                    </div>
                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 10px; background: rgba(0,240,255,0.1); border-radius: 8px;">
                        <div>
                            <p style="margin: 0; font-weight: bold;">暗色主题</p>
                            <p style="margin: 2px 0 0 0; font-size: 0.8rem; opacity: 0.7;">使用深色界面</p>
                        </div>
                        <label class="switch">
                            <input type="checkbox" checked>
                            <span class="slider"></span>
                        </label>
                    </div>
                    <div style="padding: 10px; background: rgba(0,240,255,0.1); border-radius: 8px;">
                        <p style="margin: 0; font-weight: bold; margin-bottom: 8px;">刷新频率</p>
                        <select style="width: 100%; padding: 8px; background: rgba(0,0,0,0.5); border: 1px solid rgba(0,240,255,0.3); border-radius: 6px; color: white;">
                            <option>10秒</option>
                            <option selected>30秒</option>
                            <option>1分钟</option>
                            <option>5分钟</option>
                        </select>
                    </div>
                </div>
            </div>
        `;
        
        const modal = document.createElement('div');
        modal.className = 'modal-overlay';
        modal.innerHTML = settingsContent;
        modal.addEventListener('click', () => {
            modal.remove();
        });
        document.body.appendChild(modal);
        
        // 添加开关样式
        const style = document.createElement('style');
        style.textContent = `
            .switch {
                position: relative;
                display: inline-block;
                width: 48px;
                height: 26px;
            }
            .switch input {
                opacity: 0;
                width: 0;
                height: 0;
            }
            .slider {
                position: absolute;
                cursor: pointer;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(255,255,255,0.2);
                transition: 0.3s;
                border-radius: 26px;
            }
            .slider:before {
                position: absolute;
                content: "";
                height: 20px;
                width: 20px;
                left: 3px;
                bottom: 3px;
                background: white;
                transition: 0.3s;
                border-radius: 50%;
            }
            input:checked + .slider {
                background: #00f0ff;
                box-shadow: 0 0 10px rgba(0,240,255,0.5);
            }
            input:checked + .slider:before {
                transform: translateX(22px);
            }
        `;
        document.head.appendChild(style);
    }

    handleLogout() {
        // 处理退出登录
        this.toggleUserDropdown();
        
        // 创建确认弹窗
        const confirmContent = `
            <div style="padding: 24px; background: rgba(0,0,0,0.85); border-radius: 16px; color: white; max-width: 380px; text-align: center; border: 1px solid rgba(255,0,110,0.3);">
                <div style="width: 64px; height: 64px; margin: 0 auto 16px; border-radius: 50%; background: rgba(255,0,110,0.2); display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-sign-out-alt" style="font-size: 2rem; color: #ff006e;"></i>
                </div>
                <h3 style="color: #ff006e; margin: 0 0 12px 0; font-size: 1.2rem;">确认退出登录？</h3>
                <p style="color: rgba(255,255,255,0.7); margin: 0 0 20px 0;">退出后将需要重新登录才能使用所有功能</p>
                <div style="display: flex; gap: 12px;">
                    <button onclick="evChargeApp.cancelLogout()" style="flex: 1; padding: 10px 20px; background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); border-radius: 8px; color: white; cursor: pointer; transition: all 0.3s;">取消</button>
                    <button onclick="evChargeApp.confirmLogout()" style="flex: 1; padding: 10px 20px; background: linear-gradient(135deg, #ff006e, #ff6b9d); border: none; border-radius: 8px; color: white; cursor: pointer; transition: all 0.3s; box-shadow: 0 0 20px rgba(255,0,110,0.4);">确认退出</button>
                </div>
            </div>
        `;
        
        const confirmModal = document.createElement('div');
        confirmModal.className = 'modal-overlay';
        confirmModal.id = 'logout-confirm-modal';
        confirmModal.innerHTML = confirmContent;
        document.body.appendChild(confirmModal);
        
        this.showNotification('确认退出登录', 'warning');
    }

    cancelLogout() {
        // 取消退出登录
        const modal = document.getElementById('logout-confirm-modal');
        if (modal) {
            modal.remove();
        }
        this.showNotification('已取消退出', 'info');
    }

    confirmLogout() {
        // 确认退出登录
        const modal = document.getElementById('logout-confirm-modal');
        if (modal) {
            modal.remove();
        }
        
        // 显示退出动画
        const logoutContent = `
            <div style="padding: 32px; background: rgba(0,0,0,0.9); border-radius: 16px; color: white; max-width: 320px; text-align: center;">
                <div style="width: 80px; height: 80px; margin: 0 auto 20px; border-radius: 50%; background: linear-gradient(135deg, #00f0ff, #0066ff); display: flex; align-items: center; justify-content: center; animation: pulse 1s ease-in-out infinite;">
                    <i class="fas fa-user-circle" style="font-size: 3rem; color: #0a0e17;"></i>
                </div>
                <h3 style="color: #00f0ff; margin: 0 0 8px 0;">正在退出...</h3>
                <p style="color: rgba(255,255,255,0.6); margin: 0;">感谢您使用EVCharge</p>
                <div style="margin-top: 20px; width: 100%; height: 3px; background: rgba(255,255,255,0.2); border-radius: 2px; overflow: hidden;">
                    <div style="height: 100%; width: 100%; background: linear-gradient(90deg, #00f0ff, #9d4edd); animation: slide 1.5s ease-out;"></div>
                </div>
            </div>
        `;
        
        const logoutModal = document.createElement('div');
        logoutModal.className = 'modal-overlay';
        document.body.appendChild(logoutModal);
        logoutModal.innerHTML = logoutContent;
        
        // 添加动画样式
        const style = document.createElement('style');
        style.textContent = `
            @keyframes pulse {
                0%, 100% { transform: scale(1); opacity: 1; }
                50% { transform: scale(1.1); opacity: 0.8; }
            }
            @keyframes slide {
                from { width: 0; }
                to { width: 100%; }
            }
        `;
        document.head.appendChild(style);
        
        // 模拟退出过程
        setTimeout(() => {
            logoutModal.remove();
            this.resetToLogin();
        }, 1500);
    }

    resetToLogin() {
        // 重置到登录状态
        const loginContent = `
            <div style="padding: 32px; background: rgba(0,0,0,0.85); border-radius: 16px; color: white; max-width: 400px; border: 1px solid rgba(0,240,255,0.3); box-shadow: 0 0 30px rgba(0,240,255,0.3);">
                <div style="text-align: center; margin-bottom: 24px;">
                    <div style="width: 80px; height: 80px; margin: 0 auto 16px; border-radius: 50%; background: linear-gradient(135deg, #00f0ff, #0066ff); display: flex; align-items: center; justify-content: center;">
                        <i class="fas fa-bolt" style="font-size: 3rem; color: #0a0e17;"></i>
                    </div>
                    <h2 style="color: #00f0ff; margin: 0; font-size: 1.5rem;">EVCharge</h2>
                    <p style="color: rgba(255,255,255,0.6); margin: 4px 0 0 0;">新能源汽车智能服务平台</p>
                </div>
                
                <div style="display: flex; flex-direction: column; gap: 12px;">
                    <input type="text" placeholder="用户名" style="padding: 12px 16px; background: rgba(255,255,255,0.1); border: 1px solid rgba(0,240,255,0.3); border-radius: 8px; color: white; font-size: 1rem;" id="login-username">
                    <input type="password" placeholder="密码" style="padding: 12px 16px; background: rgba(255,255,255,0.1); border: 1px solid rgba(0,240,255,0.3); border-radius: 8px; color: white; font-size: 1rem;" id="login-password">
                    
                    <button onclick="evChargeApp.handleLogin()" style="padding: 12px; background: linear-gradient(135deg, #00f0ff, #0066ff); border: none; border-radius: 8px; color: #0a0e17; font-size: 1rem; font-weight: bold; cursor: pointer; transition: all 0.3s; box-shadow: 0 0 20px rgba(0,240,255,0.4);">
                        <i class="fas fa-sign-in-alt"></i> 登录
                    </button>
                </div>
                
                <div style="margin-top: 16px; display: flex; justify-content: space-between; font-size: 0.85rem; color: rgba(255,255,255,0.5);">
                    <a href="#" style="color: rgba(0,240,255,0.7); text-decoration: none;">忘记密码?</a>
                    <a href="#" style="color: rgba(0,240,255,0.7); text-decoration: none;">注册账户</a>
                </div>
            </div>
        `;
        
        const loginModal = document.createElement('div');
        loginModal.className = 'modal-overlay';
        loginModal.id = 'login-modal';
        document.body.appendChild(loginModal);
        loginModal.innerHTML = loginContent;
        
        this.showNotification('已退出登录，请重新登录', 'info');
    }

    handleLogin() {
        // 处理登录
        const username = document.getElementById('login-username')?.value || '';
        const password = document.getElementById('login-password')?.value || '';
        
        if (!username || !password) {
            this.showNotification('请输入用户名和密码', 'error');
            return;
        }
        
        // 显示登录动画
        const loginModal = document.getElementById('login-modal');
        if (loginModal) {
            loginModal.innerHTML = `
                <div style="padding: 32px; background: rgba(0,0,0,0.85); border-radius: 16px; color: white; max-width: 320px; text-align: center;">
                    <div style="width: 64px; height: 64px; margin: 0 auto 16px; border-radius: 50%; background: rgba(74,222,128,0.2); display: flex; align-items: center; justify-content: center;">
                        <i class="fas fa-check-circle" style="font-size: 2.5rem; color: #4ade80;"></i>
                    </div>
                    <h3 style="color: #4ade80; margin: 0;">登录成功!</h3>
                    <p style="color: rgba(255,255,255,0.6); margin: 8px 0 0 0;">欢迎回来，${username}</p>
                </div>
            `;
        }
        
        // 延迟后关闭登录弹窗
        setTimeout(() => {
            const modal = document.getElementById('login-modal');
            if (modal) {
                modal.remove();
            }
            this.showNotification('登录成功，欢迎使用EVCharge', 'success');
        }, 1500);
    }

    showUserPanel() {
        // 显示用户面板
        this.showNotification('用户信息面板', 'info');
        const userInfo = {
            name: 'EV用户',
            vehicle: '特斯拉 Model 3',
            battery: '85%',
            mileage: '380 km'
        };
        const panelContent = `
            <div style="padding: 15px; background: rgba(0,0,0,0.8); border-radius: 12px; color: white;">
                <h3 style="color: #00f0ff; margin-bottom: 10px;">👤 用户信息</h3>
                <p><strong>用户名:</strong> ${userInfo.name}</p>
                <p><strong>车辆:</strong> ${userInfo.vehicle}</p>
                <p><strong>电池电量:</strong> <span style="color: #4ade80;">${userInfo.battery}</span></p>
                <p><strong>续航里程:</strong> ${userInfo.mileage}</p>
            </div>
        `;
        const modal = document.createElement('div');
        modal.className = 'modal-overlay';
        modal.innerHTML = panelContent;
        modal.addEventListener('click', () => {
            modal.remove();
        });
        document.body.appendChild(modal);
    }

    showNotifications() {
        // 切换通知下拉菜单显示/隐藏
        const dropdown = document.querySelector('.notification-dropdown');
        
        if (dropdown) {
            dropdown.classList.toggle('active');
            
            // 如果打开菜单，更新通知列表
            if (dropdown.classList.contains('active')) {
                this.renderNotificationList();
                // 标记所有通知为已读
                this.notifications.forEach(n => n.read = true);
                this.updateNotificationBadge();
            }
        }
    }
    
    renderNotificationList() {
        // 渲染通知列表到下拉菜单
        const listContainer = document.getElementById('notifications-list');
        const countElement = document.getElementById('notifications-count');
        
        if (!listContainer || !countElement) return;
        
        const notifications = this.notifications.length > 0 ? this.notifications : [];
        
        // 更新通知数量
        countElement.textContent = `${notifications.length} 条`;
        
        if (notifications.length === 0) {
            listContainer.innerHTML = `
                <div class="empty-notifications">
                    <i class="fas fa-inbox"></i>
                    <p>暂无通知</p>
                </div>
            `;
            return;
        }
        
        let html = '';
        notifications.forEach((notif) => {
            const iconClass = notif.type === 'success' ? 'check-circle' : notif.type === 'warning' ? 'alert-circle' : 'info-circle';
            html += `
                <div class="notification-item ${notif.read ? '' : 'unread'}" onclick="evChargeApp.markNotificationAsRead(${notif.id})">
                    <div class="notification-icon ${notif.type}">
                        <i class="fas fa-${iconClass}"></i>
                    </div>
                    <div class="notification-content">
                        <p class="notification-title">${notif.title}</p>
                        <p class="notification-message">${notif.message}</p>
                    </div>
                    <span class="notification-time">${notif.time}</span>
                </div>
            `;
        });
        
        listContainer.innerHTML = html;
    }
    
    markAllAsRead() {
        // 标记所有通知为已读
        this.notifications.forEach(n => n.read = true);
        this.updateNotificationBadge();
        this.renderNotificationList();
        this.showNotification('所有通知已标记为已读', 'success');
    }

    markNotificationAsRead(notificationId) {
        // 标记单个通知为已读
        const notif = this.notifications.find(n => n.id === notificationId);
        if (notif) {
            notif.read = true;
            this.updateNotificationBadge();
        }
    }

    showNotification(message, type = 'info') {
        // 创建通知元素
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
            <span>${message}</span>
        `;
        
        // 添加到页面
        document.body.appendChild(notification);
        
        // 显示通知
        setTimeout(() => {
            notification.classList.add('show');
        }, 10);
        
        // 3秒后移除
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }

    showLoading() {
        document.getElementById('loading').style.display = 'flex';
    }

    hideLoading() {
        document.getElementById('loading').style.display = 'none';
    }

    clearMarkers() {
        this.markers.forEach(marker => {
            this.map.remove(marker);
        });
        this.markers = [];
    }

    clearCurrentMarker() {
        // 可以添加特定的当前标记清除逻辑
    }

    toggleFullscreen() {
        const mapContainer = document.getElementById('map');
        if (!document.fullscreenElement) {
            mapContainer.requestFullscreen().catch(err => {
                console.error(`全屏请求失败: ${err.message}`);
            });
        } else {
            document.exitFullscreen();
        }
    }

    async saveRouteData(data) {
        try {
            const response = await fetch(`${this.backendUrl}/api/save-data`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    ...data,
                    timestamp: new Date().toISOString(),
                    user: 'EV用户'
                })
            });
            
            const result = await response.json();
            this.showNotification('路线数据保存成功', 'success');
            this.addActivity('保存路线', '路线数据已保存到服务器');
            
            // 在API结果区域显示保存信息
            document.getElementById('api-results').innerHTML = `
                <div style="color: #4ade80;">
                    <i class="fas fa-check-circle"></i>
                    <strong>数据保存成功</strong><br>
                    <small>文件: ${result.filename.split('\\').pop()}</small><br>
                    <small>时间: ${new Date().toLocaleTimeString()}</small>
                </div>
            `;
        } catch (error) {
            console.error('数据保存失败:', error);
            this.showNotification('数据保存失败', 'error');
        }
    }

    // API测试函数
    async testAPI(type) {
        const apiResultsEl = document.getElementById('api-results');
        
        try {
            let url = '';
            let description = '';
            
            switch(type) {
                case 'health':
                    url = '/health';
                    description = '健康检查';
                    break;
                case 'geocode':
                    url = '/geocode?address=北京市天安门';
                    description = '地理编码';
                    break;
                case 'reverse':
                    url = '/reverse-geocode?location=116.397428,39.90923';
                    description = '逆地理编码';
                    break;
            }
            
            apiResultsEl.innerHTML = '<div class="loading"></div> 测试中...';
            
            const response = await this.apiRequest(url);
            
            apiResultsEl.innerHTML = `
                <div style="color: #4ade80; margin-bottom: 10px;">
                    <i class="fas fa-check-circle"></i>
                    <strong>${description} 成功</strong>
                </div>
                <pre style="
                    background: #1e293b;
                    color: #e2e8f0;
                    padding: 12px;
                    border-radius: 8px;
                    font-size: 0.85em;
                    overflow: auto;
                    max-height: 150px;
                    margin: 0;
                ">${JSON.stringify(response, null, 2)}</pre>
            `;
            
            this.addActivity('API测试', `${description} 测试成功`);
            
        } catch (error) {
            apiResultsEl.innerHTML = `
                <div style="color: #ef4444;">
                    <i class="fas fa-exclamation-circle"></i>
                    <strong>API测试失败</strong><br>
                    <small>${error.message}</small>
                </div>
            `;
        }
    }
}

// 添加通知样式
const notificationStyles = document.createElement('style');
notificationStyles.textContent = `
.notification {
    position: fixed;
    top: 100px;
    right: 24px;
    background: white;
    color: #1e293b;
    padding: 16px 24px;
    border-radius: 12px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
    display: flex;
    align-items: center;
    gap: 12px;
    z-index: 9999;
    transform: translateX(400px);
    transition: transform 0.3s ease;
    max-width: 350px;
    border-left: 4px solid #4361ee;
}

.notification.show {
    transform: translateX(0);
}

.notification-success {
    border-left-color: #4ade80;
}

.notification-error {
    border-left-color: #ef4444;
}

.notification-warning {
    border-left-color: #f59e0b;
}

.notification-info {
    border-left-color: #4361ee;
}

.notification i {
    font-size: 1.2rem;
}

.notification-success i {
    color: #4ade80;
}

.notification-error i {
    color: #ef4444;
}

.notification-warning i {
    color: #f59e0b;
}

.notification-info i {
    color: #4361ee;
}

.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.7);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 1000;
    cursor: pointer;
}

.modal-overlay > div {
    cursor: default;
    animation: fadeIn 0.3s ease;
}

@keyframes fadeIn {
    from {
        opacity: 0;
        transform: scale(0.9);
    }
    to {
        opacity: 1;
        transform: scale(1);
    }
}

.user-info, .btn-notification {
    cursor: pointer;
}
`;
document.head.appendChild(notificationStyles);

// 全局函数供HTML按钮调用
window.testAPI = (type) => evChargeApp.testAPI(type);
window.saveCurrentRoute = () => evChargeApp.saveRouteData({ route: 'current' });
window.clearAllMarkers = () => evChargeApp.clearMarkers();
window.showHelp = () => {
    evChargeApp.showNotification('查看控制台了解更多信息', 'info');
    console.log(`
    ========================================
    EVCharge 使用帮助：
    
    1. 定位功能：点击"更新位置"获取当前位置
    2. 搜索充电桩：输入地址，选择范围，点击搜索
    3. 路线规划：输入起点和终点，点击开始导航
    4. 地图操作：使用地图控件进行缩放、定位等操作
    5. API测试：点击快捷操作测试后端接口
    
    项目路径：D:\\5
    后端地址：http://localhost:3000
    高德密钥：b3e4925855770e4c79aea6f7c24b051b
    ========================================
    `);
};

// 页面加载完成后初始化应用
let evChargeApp;
window.onload = () => {
    evChargeApp = new EVChargeApp();
};
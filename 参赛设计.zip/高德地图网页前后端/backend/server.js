const express = require('express');
const axios = require('axios');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const app = express();

// 配置
const AMAP_KEY = 'e9f2dd5c2025ab00ea8bba1a19bee083'; // Web服务密钥
const AMAP_KEY_BACKUP = 'b3e4925855770e4c79aea6f7c24b051b'; // 备用密钥
const DATA_PATH = __dirname; // 当前目录 D:\5\backend

// 中间件 - 配置CORS允许公网访问
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));

// 1. 获取当前位置（IP定位）
app.get('/api/location/ip', async (req, res) => {
  try {
    const response = await axios.get(
      `https://restapi.amap.com/v3/ip?key=${AMAP_KEY}`
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 2. 地址转坐标
app.get('/api/geocode', async (req, res) => {
  try {
    const { address, city } = req.query;
    const response = await axios.get(
      `https://restapi.amap.com/v3/geocode/geo?key=${AMAP_KEY}&address=${encodeURIComponent(address)}&city=${city || ''}`
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 3. 搜索附近充电桩
app.get('/api/charging-stations', async (req, res) => {
  try {
    const { location, radius = 5000, page = 1, size = 20 } = req.query;
    const response = await axios.get(
      `https://restapi.amap.com/v5/place/around?key=${AMAP_KEY}&location=${location}&keywords=充电站&radius=${radius}&page=${page}&page_size=${size}`
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 4. 路线规划（电动汽车模式）
app.get('/api/route-planning', async (req, res) => {
  try {
    const { origin, destination, waypoints } = req.query;
    let url = `https://restapi.amap.com/v5/direction/driving?key=${AMAP_KEY}&origin=${origin}&destination=${destination}&show_fields=polyline,tolls,cost&strategy=0`;
    
    if (waypoints) {
      url += `&waypoints=${waypoints}`;
    }
    
    const response = await axios.get(url);
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 5. 逆地理编码（坐标转地址）
app.get('/api/reverse-geocode', async (req, res) => {
  try {
    const { location } = req.query;
    const response = await axios.get(
      `https://restapi.amap.com/v3/geocode/regeo?key=${AMAP_KEY}&location=${location}&extensions=all`
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 6. 保存用户数据到本地文件系统
app.post('/api/save-data', (req, res) => {
  try {
    const data = req.body;
    const timestamp = new Date().getTime();
    const filename = path.join(__dirname, `user_data_${timestamp}.json`);
    
    fs.writeFileSync(filename, JSON.stringify(data, null, 2));
    res.json({ success: true, message: '数据保存成功', filename });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 7. 健康检查
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    amap_key: AMAP_KEY.substring(0, 8) + '...',
    data_path: DATA_PATH
  });
});

// 8. 提供前端页面
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// 9. 启动服务器
const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => {
  console.log('========================================');
  console.log('🚀 新能源汽车服务系统后端已启动');
  console.log('========================================');
  console.log(`📁 后端路径: ${__dirname}`);
  console.log(`🌐 服务器地址: http://localhost:${PORT}`);
  console.log(`🗺️  高德密钥: ${AMAP_KEY.substring(0, 8)}...`);
  console.log(`💾 数据保存路径: ${DATA_PATH}`);
  console.log(`📄 API文档:`);
  console.log(`   - 健康检查: GET /api/health`);
  console.log(`   - IP定位: GET /api/location/ip`);
  console.log(`   - 地理编码: GET /api/geocode?address=地址`);
  console.log(`   - 充电桩搜索: GET /api/charging-stations?location=坐标`);
  console.log(`   - 路线规划: GET /api/route-planning?origin=起点&destination=终点`);
  console.log('========================================');
});